from __future__ import print_function # Python 2/3 compatibility
import os
import socket
import boto3
import paramiko
from sftp import SFTP


def lambda_handler(event, context):
    username = event['username']
    password = event['password']
    hostname = event['endpoint']
    # port = event.get('port') or 22
    ftp_dir = event['path']
    key_id = event['id']
    key = event['name']
    bucket_name = event['s3StagingBucket']
    s3_client = boto3.client('s3')

    try:
        with SFTP(hostname=hostname, username=username, password=password) as sftp:
            sftp.chdir(ftp_dir)
            for key in sftp.listdir():
                # file path on sftp
                remote_file_path = os.path.normpath(os.path.join(ftp_dir, key)).replace('\\', '/')
                with sftp.file(remote_file_path, 'rb') as body:
                    response = s3_client.put_object(
                        body=body,
                        bucket=bucket_name,
                        key=key,
                        key_id=key_id,
                    )
                    print(response)
    except (socket.error, paramiko.SSHException) as ex:
        return 'Failed to connect to {username}@{hostname}'.format(hostname=hostname, username=username,
                                                                          )