from __future__ import print_function # Python 2/3 compatibility
import os
import socket
import boto3
import paramiko
from sftp import SFTP


def lambda_handler(event, context):
    username = event["credentials"]["username"]
    password = event["credentials"]["password"]
    hostname = event['endpoint']
    # port = event.get('port') or 22
    ftp_dir = event['path']
    key_id = event['id']
    key = event['name']
    s3bucket = event['s3StagingBucket'].split('/')
    key_prefix = s3bucket[1:]
    bucket_name = s3bucket[0]
    s3_client = boto3.client('s3')

    try:
        with SFTP(hostname=hostname, username=username, password=password) as sftp:
            sftp.chdir(ftp_dir)
            for key in sftp.listdir():
                # file path on sftp
                remote_file_path = os.path.normpath(os.path.join(ftp_dir, key)).replace('\\', '/')
                with sftp.file(remote_file_path, 'rb') as body:
                    key = '/'.join(key_prefix + [key])
                    response = s3_client.put_object(
                        Body=body,
                        Bucket=bucket_name,
                        Key=key,
                        # key_id=key_id,
                    )
                    print(response)
    except (socket.error, paramiko.SSHException) as ex:
        return 'Failed to connect to {username}@{hostname}'.format(hostname=hostname, username=username)